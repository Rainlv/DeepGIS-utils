class UnAuthorizedException(Exception):
    pass

class PermissionDeniedException(Exception):
    pass